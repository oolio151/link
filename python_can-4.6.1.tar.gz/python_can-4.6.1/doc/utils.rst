Utilities
---------


.. autofunction:: can.detect_available_configs

.. autofunction:: can.cli.add_bus_arguments

.. autofunction:: can.cli.create_bus_from_namespace

